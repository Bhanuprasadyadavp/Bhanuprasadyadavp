package com.example.Collaboration24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Collaboration1Application {

	public static void main(String[] args) {
		SpringApplication.run(Collaboration1Application.class, args);
	}

}
