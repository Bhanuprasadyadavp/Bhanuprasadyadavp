package com.example.Collaboration24.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Collaboration24.entity.Collaboration;

public interface CollaborationRepository extends JpaRepository<Collaboration, Long> {
}
