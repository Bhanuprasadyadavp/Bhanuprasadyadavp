package com.example.Collaboration24.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.Collaboration24.entity.Collaboration;
import com.example.Collaboration24.repos.CollaborationRepository;

import java.util.List;
import java.util.Optional;
@Controller
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/collaborations")
public class CollaborationController {
    @Autowired
    private CollaborationRepository repository;

//    @GetMapping
//    public String collaborationForm(Model model) {
//        Collaboration collaboration = new Collaboration();
//        model.addAttribute("collaboration", collaboration);
//        return "collaborationForm";
//    }

    @PostMapping
    public ResponseEntity<Object> submitCollaboration(@RequestBody Collaboration collaboration) {
        try {
            // Print or log the received collaboration data for debugging
            System.out.println("Received Collaboration Data: " + collaboration);

            Collaboration savedCollaboration = repository.save(collaboration);
            return ResponseEntity.ok().body("{\"message\": \"Success\", \"id\": " + savedCollaboration.getId() + "}");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("{\"message\": \"Error processing the request\"}");
        }
    }
    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<?> getCollaborationById(@PathVariable Long id) {
        try {
            Optional<Collaboration> collaboration = repository.findById(id);
            return collaboration.map(value -> ResponseEntity.ok().body(value))
                    .orElseGet(() -> ResponseEntity.notFound().build());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("{\"message\": \"Error processing the request\"}");
        }
    }

    @PutMapping("/{id}")
    @ResponseBody
    public Object updateCollaboration(@PathVariable Long id, @RequestBody Collaboration updatedCollaboration) {
        try {
            Optional<Collaboration> existingCollaboration = repository.findById(id);
            return existingCollaboration.map(collab -> {
//                collab.setOrganizationName(updatedCollaboration.getOrganizationName());
                collab.setOrganizationName(updatedCollaboration.getOrganizationName());
                collab.setSector(updatedCollaboration.getSector());
                collab.setContactName(updatedCollaboration.getContactName());
                collab.setEmail(updatedCollaboration.getEmail());
                collab.setMobileNumber(updatedCollaboration.getMobileNumber());
                collab.setAlternateNumber(updatedCollaboration.getAlternateNumber());
                collab.setOfficialAddress(updatedCollaboration.getOfficialAddress());
                collab.setDepartment(updatedCollaboration.getDepartment());
                collab.setBatch(updatedCollaboration.getBatch());
                Collaboration savedCollaboration = repository.save(collab);
                return ResponseEntity.ok().body(savedCollaboration);
            }).orElseGet(() -> ResponseEntity.<Collaboration>notFound().build());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("{\"message\": \"Error processing the request\"}");
        }
    }
    
    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Object> deleteCollaboration(@PathVariable Long id) {
        try {
            repository.deleteById(id);
            return ResponseEntity.ok().body("{\"message\": \"Collaboration deleted successfully\"}");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("{\"message\": \"Error processing the request\"}");
        }
    }
}
