package com.example.Collaboration24.service;

import com.example.Collaboration24.entity.Collaboration;
import com.example.Collaboration24.repos.CollaborationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CollabrationService {

    @Autowired
    private CollaborationRepository collaborationRepository;

    public Collaboration saveCollaboration(Collaboration collaboration) {
        return collaborationRepository.save(collaboration);
    }

    public Optional<Collaboration> getCollaborationById(Long id) {
        return collaborationRepository.findById(id);
    }

    public Optional<Collaboration> updateCollaboration(Long id, Collaboration updatedCollaboration) {
        Optional<Collaboration> existingCollaboration = collaborationRepository.findById(id);
        return existingCollaboration.map(collab -> {
            collab.setOrganizationName(updatedCollaboration.getOrganizationName());
            // Update other fields as needed
            Collaboration savedCollaboration = collaborationRepository.save(collab);
            return Optional.of(savedCollaboration);
        }).orElse(Optional.empty());
    }

    public void deleteCollaboration(Long id) {
        collaborationRepository.deleteById(id);
    }

    public List<Collaboration> getAllCollaborations() {
        return collaborationRepository.findAll();
    }
}
