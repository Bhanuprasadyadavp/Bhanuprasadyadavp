package com.example.Collaboration1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Collaboration1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
